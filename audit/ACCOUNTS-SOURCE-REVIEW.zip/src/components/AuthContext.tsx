"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  AUTH_STORAGE_KEY,
  type AccountKind,
  type AuthUser,
  type ProRole,
  parseStoredUser,
} from "@/lib/auth";
import { useApp } from "@/components/AppContext";
import { track, type AccountKindProp } from "@/lib/analytics";
import {
  getBrowserSupabase,
  isSupabaseConfigured,
} from "@/lib/supabase/client";

function accountKindForAnalytics(user: AuthUser): AccountKindProp {
  if (user.kind === "broker") return "broker";
  if (user.kind === "pro") return "agent";
  if (user.kind === "seller") return "seller";
  if (user.kind === "consumer") return "consumer";
  return "unknown";
}

type AuthResult = { ok: true } | { ok: false; error: string };

type AuthContextType = {
  user: AuthUser | null;
  isLoggedIn: boolean;
  /** Whether real Supabase Auth is active (vs demo mode). */
  supabaseConfigured: boolean;
  loginAs: (user: AuthUser) => void;
  loginSellerWithCode: (code: string) => Promise<AuthResult>;
  loginPro: (proRole: ProRole, name?: string) => void;
  loginConsumer: (name?: string) => void;
  signInWithPassword: (email: string, password: string) => Promise<AuthResult>;
  signUp: (
    email: string,
    password: string,
    opts: {
      fullName: string;
      accountKind: AccountKind;
      professionalRole?: ProRole;
      trecLicense?: string;
      trecStatus?: string;
      sponsorLicenseNumber?: string;
      sponsorName?: string;
    },
  ) => Promise<AuthResult>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function initialsOf(name: string): string {
  return name
    .split(" ")
    .map((p) => p[0])
    .filter(Boolean)
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

function kindFromAccount(accountKind: string | null | undefined): AccountKind {
  if (accountKind === "broker") return "broker";
  if (accountKind === "agent") return "pro";
  return "consumer";
}

function persistUser(user: AuthUser | null) {
  try {
    if (user) {
      window.localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user));
    } else {
      window.localStorage.removeItem(AUTH_STORAGE_KEY);
    }
  } catch {
    // ignore
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { setRole } = useApp();
  const [user, setUser] = useState<AuthUser | null>(null);
  const [ready, setReady] = useState(false);

  const configured = isSupabaseConfigured();
  const supabase = useMemo(() => getBrowserSupabase(), []);

  // Load session: real Supabase when configured, otherwise demo localStorage.
  useEffect(() => {
    if (!configured || !supabase) {
      try {
        setUser(parseStoredUser(window.localStorage.getItem(AUTH_STORAGE_KEY)));
      } catch {
        setUser(null);
      }
      setReady(true);
      return;
    }

    let active = true;

    const promoted = new Set<string>();

    async function applySession(userId: string | null, email: string | null) {
      if (!userId) {
        if (active) {
          setUser(null);
          setReady(true);
        }
        return;
      }
      if (!promoted.has(userId)) {
        promoted.add(userId);
        try {
          await fetch("/api/account/promote-pro", { method: "POST" });
        } catch {
          // Stay consumer until the next sign-in.
        }
      }
      let name = email?.split("@")[0] ?? "Member";
      let kind: AccountKind = "consumer";
      let proRole: ProRole | undefined;
      try {
        const { data } = await supabase!
          .from("profiles")
          .select("full_name, account_kind, professional_role")
          .eq("id", userId)
          .maybeSingle();
        if (data) {
          name = data.full_name || name;
          kind = kindFromAccount(data.account_kind);
          proRole = (data.professional_role as ProRole | null) ?? undefined;
        }
      } catch {
        // fall back to session-derived defaults
      }
      if (!active) return;
      setUser({
        id: userId,
        name,
        email: email ?? "",
        initials: initialsOf(name),
        kind,
        proRole,
      });
      setRole(kind === "consumer" ? "consumer" : "professional");
      setReady(true);
    }

    supabase.auth
      .getSession()
      .then(({ data }) =>
        applySession(
          data.session?.user?.id ?? null,
          data.session?.user?.email ?? null,
        ),
      );

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      applySession(session?.user?.id ?? null, session?.user?.email ?? null);
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [configured, supabase, setRole]);

  const loginAs = useCallback(
    (next: AuthUser) => {
      setUser(next);
      persistUser(next);
      setRole(
        next.kind === "pro" || next.kind === "broker"
          ? "professional"
          : "consumer",
      );
      track("auth_login_succeeded", {
        account_kind: accountKindForAnalytics(next),
      });
    },
    [setRole],
  );

  const loginConsumer = useCallback(
    (name = "Jordan Hale") => {
      loginAs({
        id: "user-buyer",
        name,
        email: "jordan@storyhome.demo",
        initials: initialsOf(name),
        kind: "consumer",
      });
    },
    [loginAs],
  );

  const loginPro = useCallback(
    (proRole: ProRole, name = "Sarah Jenkins") => {
      loginAs({
        id: `user-pro-${proRole}`,
        name,
        email: `${proRole}@storyhome.demo`,
        initials: initialsOf(name),
        kind: "pro",
        proRole,
      });
    },
    [loginAs],
  );

  const loginSellerWithCode = useCallback(
    async (code: string): Promise<AuthResult> => {
      try {
        const res = await fetch("/api/seller/access", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ code }),
        });
        const data = (await res.json()) as {
          ok?: boolean;
          accessCode?: string;
          addressLabel?: string;
        };
        if (!res.ok || !data.ok || !data.accessCode) {
          return {
            ok: false,
            error: "Unable to open this portal. Check the code and try again.",
          };
        }
        loginAs({
          id: `seller-${data.accessCode}`,
          name: `Seller · ${data.addressLabel || "listing"}`,
          email: "seller@storyhome.app",
          initials: "SE",
          kind: "seller",
          sellerListingCode: data.accessCode,
        });
        return { ok: true };
      } catch {
        return {
          ok: false,
          error: "Unable to open this portal. Check the code and try again.",
        };
      }
    },
    [loginAs],
  );

  const signInWithPassword = useCallback(
    async (email: string, password: string): Promise<AuthResult> => {
      if (!supabase) return { ok: false, error: "Auth is not configured." };
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) {
        return {
          ok: false,
          error: "Unable to sign in. Check your email and password.",
        };
      }
      return { ok: true };
    },
    [supabase],
  );

  const signUp = useCallback(
    async (
      email: string,
      password: string,
      opts: {
        fullName: string;
        accountKind: AccountKind;
        professionalRole?: ProRole;
        trecLicense?: string;
        trecStatus?: string;
        sponsorLicenseNumber?: string;
        sponsorName?: string;
      },
    ): Promise<AuthResult> => {
      if (!supabase) return { ok: false, error: "Auth is not configured." };
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: opts.fullName,
            account_kind: "consumer",
            professional_role: opts.professionalRole ?? null,
            trec_license: opts.trecLicense ?? null,
            sponsor_license_number: opts.sponsorLicenseNumber ?? null,
            sponsor_name: opts.sponsorName ?? null,
          },
        },
      });
      if (error) {
        return {
          ok: false,
          error: "Unable to create this account. Try again or sign in.",
        };
      }
      return { ok: true };
    },
    [supabase],
  );

  const logout = useCallback(() => {
    if (supabase) {
      void supabase.auth.signOut();
    }
    setUser(null);
    persistUser(null);
    setRole("consumer");
  }, [supabase, setRole]);

  const value = useMemo(
    () => ({
      user: ready ? user : null,
      isLoggedIn: ready && Boolean(user),
      supabaseConfigured: configured,
      loginAs,
      loginSellerWithCode,
      loginPro,
      loginConsumer,
      signInWithPassword,
      signUp,
      logout,
    }),
    [
      ready,
      user,
      configured,
      loginAs,
      loginSellerWithCode,
      loginPro,
      loginConsumer,
      signInWithPassword,
      signUp,
      logout,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
